import { createFileRoute } from "@tanstack/react-router";
import { motion, useMotionValue, useScroll, useSpring, useTransform } from "motion/react";
import { useRef, useState, type ReactNode } from "react";
import me from "@/assets/me.jpg";
import flatlay from "@/assets/flatlay.jpg";
import field from "@/assets/field.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mira Lind — a little scrapbook portfolio" },
      { name: "description", content: "The personal scrapbook portfolio of Mira Lind: student, designer and maker of small delightful things." },
      { property: "og:title", content: "Mira Lind — a little scrapbook portfolio" },
      { property: "og:description", content: "Flip through the pages: about, experience, hobbies, skills and a hello." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const ease = [0.22, 1, 0.36, 1] as const;

function Star({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="currentColor" aria-hidden>
      <path d="M12 0c.6 6.5 5.5 11.4 12 12-6.5.6-11.4 5.5-12 12-.6-6.5-5.5-11.4-12-12C6.5 11.4 11.4 6.5 12 0Z" />
    </svg>
  );
}

function Reveal({ children, delay = 0, className = "" }: { children: ReactNode; delay?: number; className?: string }) {
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 40, rotate: -2 }}
      whileInView={{ opacity: 1, y: 0, rotate: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.8, delay, ease }}
    >
      {children}
    </motion.div>
  );
}

function Heading({ kicker, title }: { kicker: string; title: string }) {
  return (
    <div className="mb-14">
      <Reveal>
        <p className="font-hand text-2xl text-fern">{kicker}</p>
      </Reveal>
      <h2 className="font-display text-5xl leading-none md:text-7xl">
        {title.split(" ").map((w, i) => (
          <motion.span
            key={i}
            className="mr-4 inline-block"
            initial={{ opacity: 0, y: "60%", rotate: 6 }}
            whileInView={{ opacity: 1, y: 0, rotate: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: i * 0.08, ease }}
          >
            {w}
          </motion.span>
        ))}
      </h2>
    </div>
  );
}

/* Tilt card responding to mouse */
function Tilt({ children, className = "", rot = 0 }: { children: ReactNode; className?: string; rot?: number }) {
  const rx = useSpring(0, { stiffness: 200, damping: 18 });
  const ry = useSpring(0, { stiffness: 200, damping: 18 });
  return (
    <motion.div
      className={className}
      style={{ rotateX: rx, rotateY: ry, rotate: rot, transformPerspective: 800 }}
      onMouseMove={(e) => {
        const r = e.currentTarget.getBoundingClientRect();
        ry.set(((e.clientX - r.left) / r.width - 0.5) * 16);
        rx.set(-((e.clientY - r.top) / r.height - 0.5) * 16);
      }}
      onMouseLeave={() => { rx.set(0); ry.set(0); }}
      whileHover={{ scale: 1.03, rotate: 0 }}
    >
      {children}
    </motion.div>
  );
}

/* ---------- COVER: fanned card deck ---------- */
const deck = [
  { kind: "img", src: me, label: "hi, it's me" },
  { kind: "text", tone: "bg-gold", title: "fun fact", body: "I have 40+ sketchbooks" },
  { kind: "img", src: flatlay, label: "coffee & colour" },
  { kind: "text", tone: "bg-fern text-honeydew", title: "currently", body: "designing tiny worlds" },
  { kind: "img", src: field, label: "summer '26" },
  { kind: "text", tone: "bg-tea", title: "motto", body: "made with care, not perfection" },
  { kind: "text", tone: "bg-mahogany text-honeydew", title: "what I like", body: "type, film, plants, people" },
] as const;

function Cover() {
  const [spread, setSpread] = useState(false);
  const n = deck.length;
  return (
    <section className="dotgrid relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-6 pt-24 pb-16">
      <motion.p
        className="font-hand text-2xl text-fern"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.4 }}
      >
        vol. 01 — a personal scrapbook
      </motion.p>

      <div
        className="relative my-10 h-[300px] w-full max-w-5xl md:h-[360px]"
        onMouseEnter={() => setSpread(true)}
        onMouseLeave={() => setSpread(false)}
        onClick={() => setSpread((s) => !s)}
      >
        {deck.map((c, i) => {
          const mid = i - (n - 1) / 2;
          const x = mid * (spread ? 150 : 95);
          const rot = mid * (spread ? 6 : 9);
          const y = Math.abs(mid) * (spread ? 18 : 10);
          return (
            <motion.div
              key={i}
              drag
              dragSnapToOrigin
              className="absolute top-1/2 left-1/2 -mt-[130px] -ml-[90px] h-[260px] w-[180px] cursor-grab active:cursor-grabbing md:-mt-[150px] md:-ml-[105px] md:h-[300px] md:w-[210px]"
              initial={{ x: 0, y: 600, rotate: 0, opacity: 0 }}
              animate={{ x, y, rotate: rot, opacity: 1 }}
              transition={{ type: "spring", stiffness: 120, damping: 16, delay: spread ? 0 : 0.2 + i * 0.09 }}
              whileHover={{ y: y - 30, rotate: 0, scale: 1.08, zIndex: 20 }}
              style={{ zIndex: i }}
            >
              {c.kind === "img" ? (
                <div className="paper h-full w-full rounded-md p-2 pb-10">
                  <img src={c.src} alt={c.label} className="h-full w-full rounded-sm object-cover" draggable={false} />
                  <p className="font-hand mt-1 text-center text-xl">{c.label}</p>
                </div>
              ) : (
                <div className={`${c.tone} flex h-full w-full flex-col justify-between rounded-md p-5 shadow-lift`}>
                  <Star className="h-6 w-6" />
                  <div>
                    <p className="font-hand text-xl opacity-80">{c.title}</p>
                    <p className="font-display text-3xl leading-tight">{c.body}</p>
                  </div>
                </div>
              )}
            </motion.div>
          );
        })}
      </div>

      <motion.h1
        className="font-display text-center text-6xl leading-[0.9] md:text-8xl"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1, duration: 0.9, ease }}
      >
        Hello! I'm <em className="text-fern">Mira</em>
      </motion.h1>
      <motion.p
        className="mt-5 max-w-md text-center text-lg text-muted-foreground"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.3 }}
      >
        Design student & maker of small, delightful things. Welcome to my little corner of the internet.
      </motion.p>
      <p className="font-hand mt-6 text-lg text-muted-foreground">(hover or drag the cards ↑)</p>

      <Star className="floaty absolute top-28 left-[8%] h-10 w-10 text-gold [--r:12deg]" />
      <Star className="floaty absolute right-[10%] bottom-24 h-14 w-14 text-fern [animation-delay:-2s]" />
      <Star className="floaty absolute top-1/3 right-[6%] h-6 w-6 text-mahogany [animation-delay:-4s]" />
    </section>
  );
}

/* ---------- NAV ---------- */
const nav = ["about", "experience", "hobbies", "skills", "contact"];
function Nav() {
  const { scrollYProgress } = useScroll();
  const w = useSpring(scrollYProgress, { stiffness: 120, damping: 25 });
  return (
    <header className="fixed inset-x-0 top-0 z-50 flex justify-center px-4 pt-4">
      <nav className="paper flex items-center gap-1 rounded-full px-3 py-2 text-sm">
        <a href="#top" className="font-display mr-2 px-2 text-lg">M.</a>
        {nav.map((n) => (
          <a key={n} href={`#${n}`} className="hidden rounded-full px-3 py-1 transition-colors hover:bg-tea sm:block">
            {n}
          </a>
        ))}
      </nav>
      <motion.div className="fixed top-0 left-0 h-1 origin-left bg-gold" style={{ scaleX: w, width: "100%" }} />
    </header>
  );
}

/* ---------- ABOUT ---------- */
function About() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [60, -60]);
  return (
    <section id="about" ref={ref} className="mx-auto max-w-6xl px-6 py-32">
      <Heading kicker="page one" title="About me" />
      <div className="grid items-start gap-12 md:grid-cols-[1fr_1.2fr]">
        <motion.div style={{ y }} className="relative mx-auto w-full max-w-sm">
          <Tilt rot={-4} className="tape paper rounded-sm p-3 pb-14">
            <img src={me} alt="Portrait of Mira" width={768} height={960} loading="lazy" className="w-full rounded-sm" />
            <p className="font-hand absolute bottom-3 left-0 w-full text-center text-2xl">me, probably thinking about fonts</p>
          </Tilt>
          <motion.div
            className="absolute -right-6 -bottom-6 grid h-24 w-24 place-items-center rounded-full bg-gold text-center"
            whileHover={{ rotate: 20, scale: 1.1 }}
          >
            <span className="font-hand text-xl leading-none">est.<br />2005</span>
          </motion.div>
        </motion.div>

        <div className="space-y-6">
          <Reveal>
            <div className="lined paper rounded-md p-8 leading-7">
              <p className="font-display text-3xl">Hi there!</p>
              <p className="mt-3 text-muted-foreground">
                I'm a visual communication student who loves turning messy ideas into tidy, warm, human things — posters,
                websites, little zines. I believe good design feels like a handwritten note.
              </p>
            </div>
          </Reveal>
          <div className="grid gap-4 sm:grid-cols-2">
            <Reveal delay={0.1}>
              <div className="rotate-1 rounded-md bg-honeydew p-6">
                <p className="font-hand text-xl text-fern">the basics</p>
                <ul className="mt-2 space-y-1 text-sm">
                  <li>📍 Berlin, Germany</li>
                  <li>🎓 BA Visual Communication</li>
                  <li>🗣 English, German, Bahasa</li>
                </ul>
              </div>
            </Reveal>
            <Reveal delay={0.2}>
              <div className="-rotate-2 rounded-md bg-tea p-6">
                <p className="font-hand text-xl text-fern">into lately</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {["film photos", "risograph", "matcha", "indie games", "houseplants"].map((t) => (
                    <motion.span key={t} whileHover={{ rotate: -6, scale: 1.1 }} className="rounded-full bg-paper px-3 py-1 text-xs">
                      {t}
                    </motion.span>
                  ))}
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- EXPERIENCE ---------- */
const exp = [
  { date: "2025 — now", org: "Student Design Collective", role: "Creative Lead", text: "Leading a team of 8 to brand campus events, from posters to motion teasers.", tone: "bg-honeydew" },
  { date: "Summer 2025", org: "Studio Olive", role: "Design Intern", text: "Built social templates and helped ship a packaging refresh for a local café.", tone: "bg-tea" },
  { date: "2024 — 2025", org: "Uni Magazine 'Leaflet'", role: "Layout Editor", text: "Designed 6 issues and introduced a new editorial type system.", tone: "bg-gold" },
  { date: "2023", org: "Art & Code Club", role: "Workshop Host", text: "Taught 30+ peers creative coding basics with p5.js.", tone: "bg-honeydew" },
];
function Experience() {
  return (
    <section id="experience" className="dotgrid py-32">
      <div className="mx-auto max-w-5xl px-6">
        <Heading kicker="page two" title="Where I've been" />
        <div className="relative">
          <div className="absolute top-0 left-4 h-full border-l-2 border-dashed border-fern md:left-1/2" />
          {exp.map((e, i) => (
            <Reveal key={i} delay={0.05} className={`relative mb-12 pl-12 md:w-1/2 md:pl-0 ${i % 2 ? "md:ml-auto md:pl-12" : "md:pr-12"}`}>
              <span className={`absolute top-6 left-[9px] h-4 w-4 rounded-full border-2 border-mahogany bg-gold md:left-auto ${i % 2 ? "md:-left-2" : "md:-right-2"}`} />
              <Tilt rot={i % 2 ? 1.5 : -1.5} className={`${e.tone} rounded-md p-6 shadow-lift`}>
                <div className="flex items-center justify-between">
                  <span className="font-hand text-xl">{e.date}</span>
                  <span className="text-xs tracking-widest uppercase">{e.role}</span>
                </div>
                <h3 className="font-display mt-2 text-3xl">{e.org}</h3>
                <p className="mt-2 text-sm opacity-80">{e.text}</p>
              </Tilt>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- HOBBIES ---------- */
const hobbies = [
  { emoji: "📷", name: "Film photography", note: "35mm, mostly golden hour and friends.", tone: "bg-tea", r: -6 },
  { emoji: "🌿", name: "Plant parent", note: "23 plants. All named. One is dramatic.", tone: "bg-honeydew", r: 4 },
  { emoji: "☕", name: "Café hopping", note: "Rating every flat white in Berlin.", tone: "bg-gold", r: -3 },
  { emoji: "🎮", name: "Cozy games", note: "Stardew, Unpacking, A Short Hike.", tone: "bg-fern text-honeydew", r: 5 },
  { emoji: "✂️", name: "Zine making", note: "Cut, paste, photocopy, repeat.", tone: "bg-honeydew", r: -4 },
  { emoji: "🎧", name: "Vinyl digging", note: "Bossa nova & city pop finds.", tone: "bg-tea", r: 3 },
];
function Hobbies() {
  return (
    <section id="hobbies" className="mx-auto max-w-6xl px-6 py-32">
      <Heading kicker="page three" title="Things I love" />
      <div className="grid grid-cols-2 gap-6 md:grid-cols-3">
        {hobbies.map((h, i) => (
          <motion.div
            key={h.name}
            className={`group relative aspect-square cursor-pointer overflow-hidden rounded-md ${h.tone} p-6 shadow-lift`}
            initial={{ opacity: 0, scale: 0.6, rotate: h.r * 3 }}
            whileInView={{ opacity: 1, scale: 1, rotate: h.r }}
            viewport={{ once: true }}
            transition={{ type: "spring", stiffness: 140, damping: 14, delay: i * 0.07 }}
            whileHover={{ rotate: 0, scale: 1.05, zIndex: 10 }}
          >
            <motion.span className="block text-5xl md:text-6xl" whileHover={{ rotate: [0, -15, 15, 0] }} transition={{ duration: 0.5 }}>
              {h.emoji}
            </motion.span>
            <h3 className="font-display absolute bottom-6 left-6 text-2xl leading-tight transition-transform duration-500 group-hover:-translate-y-14 md:text-3xl">
              {h.name}
            </h3>
            <p className="font-hand absolute right-6 bottom-5 left-6 translate-y-10 text-lg leading-tight opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
              {h.note}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ---------- SKILLS ---------- */
const skills = [
  { group: "Technical", tone: "bg-honeydew", items: ["HTML & CSS", "JavaScript", "React", "p5.js", "Webflow"] },
  { group: "Design", tone: "bg-tea", items: ["Branding", "Editorial layout", "Typography", "UI / UX", "Illustration"] },
  { group: "Tools", tone: "bg-gold", items: ["Figma", "Illustrator", "InDesign", "Photoshop", "After Effects", "Procreate"] },
  { group: "Other", tone: "bg-fern text-honeydew", items: ["Public speaking", "Team leading", "Workshops", "Photography"] },
];
function Skills() {
  return (
    <section id="skills" className="overflow-hidden bg-honeydew/50 py-32">
      <div className="mb-16 flex whitespace-nowrap">
        <div className="marquee font-display flex shrink-0 gap-10 pr-10 text-6xl text-fern md:text-8xl">
          {Array.from({ length: 2 }).flatMap((_, k) =>
            ["design", "code", "type", "motion", "play"].map((w) => (
              <span key={`${k}${w}`} className="flex items-center gap-10">
                {w} <Star className="h-8 w-8 text-gold" />
              </span>
            )),
          )}
        </div>
      </div>
      <div className="mx-auto max-w-6xl px-6">
        <Heading kicker="page four" title="My toolbox" />
        <div className="grid gap-8 md:grid-cols-2">
          {skills.map((s, i) => (
            <Reveal key={s.group} delay={i * 0.08}>
              <Tilt rot={i % 2 ? 1 : -1} className={`${s.tone} rounded-md p-8 shadow-lift`}>
                <div className="flex items-baseline justify-between">
                  <h3 className="font-display text-4xl">{s.group}</h3>
                  <span className="font-hand text-2xl">0{i + 1}</span>
                </div>
                <div className="mt-6 flex flex-wrap gap-3">
                  {s.items.map((it, j) => (
                    <motion.span
                      key={it}
                      drag
                      dragSnapToOrigin
                      whileHover={{ rotate: j % 2 ? 5 : -5, y: -4 }}
                      whileTap={{ scale: 0.92 }}
                      className="cursor-grab rounded-full border border-current bg-paper/70 px-4 py-2 text-sm text-mahogany"
                    >
                      {it}
                    </motion.span>
                  ))}
                </div>
              </Tilt>
            </Reveal>
          ))}
        </div>
        <p className="font-hand mt-8 text-center text-xl text-muted-foreground">psst — the stickers are draggable</p>
      </div>
    </section>
  );
}

/* ---------- CONTACT ---------- */
function Contact() {
  const [copied, setCopied] = useState(false);
  const email = "hello@miralind.com";
  const x = useMotionValue(0);
  return (
    <section id="contact" className="mx-auto max-w-5xl px-6 py-32">
      <Heading kicker="page five" title="Say hello" />
      <div className="grid gap-10 md:grid-cols-[1.3fr_1fr]">
        <Reveal>
          <div className="relative rounded-md border-2 border-dashed border-fern bg-paper p-8 shadow-lift">
            <div className="absolute top-6 right-6 grid h-20 w-16 rotate-6 place-items-center rounded-sm bg-gold">
              <Star className="h-8 w-8 text-mahogany" />
            </div>
            <p className="font-hand text-2xl text-fern">postcard to:</p>
            <p className="font-display mt-2 text-3xl leading-tight md:text-4xl">you, the lovely<br />visitor</p>
            <p className="mt-6 max-w-sm text-muted-foreground">
              Got a project, a collab idea, or just want to swap café recommendations? My inbox is always open.
            </p>
            <motion.button
              style={{ x }}
              whileHover={{ scale: 1.05, rotate: -2 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => {
                navigator.clipboard?.writeText(email);
                setCopied(true);
                setTimeout(() => setCopied(false), 1800);
              }}
              className="mt-8 rounded-full bg-mahogany px-7 py-4 font-medium text-honeydew"
            >
              {copied ? "copied! ✿" : email}
            </motion.button>
          </div>
        </Reveal>
        <div className="flex flex-col gap-4">
          {[
            { n: "Instagram", h: "@mira.makes", tone: "bg-tea", r: -2 },
            { n: "LinkedIn", h: "in/miralind", tone: "bg-honeydew", r: 1.5 },
            { n: "Behance", h: "be/miralind", tone: "bg-gold", r: -1 },
            { n: "Phone", h: "+49 000 000 000", tone: "bg-fern text-honeydew", r: 2 },
          ].map((s, i) => (
            <Reveal key={s.n} delay={i * 0.08}>
              <motion.a
                href="#"
                style={{ rotate: s.r }}
                whileHover={{ rotate: 0, x: -10, scale: 1.03 }}
                className={`${s.tone} flex items-center justify-between rounded-md px-6 py-5 shadow-lift`}
              >
                <span className="font-display text-2xl">{s.n}</span>
                <span className="font-hand text-xl">{s.h} →</span>
              </motion.a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- ENDING ---------- */
function Ending() {
  return (
    <section className="dotgrid relative overflow-hidden px-6 py-40 text-center">
      <Star className="spin-slow absolute top-16 left-1/2 h-16 w-16 -translate-x-1/2 text-gold" />
      <Reveal>
        <p className="font-hand text-3xl text-fern">the last page</p>
        <h2 className="font-display mx-auto mt-4 max-w-3xl text-5xl leading-[0.95] md:text-7xl">
          Thanks for visiting my little corner of the <em className="text-fern">internet</em>.
        </h2>
        <p className="font-hand mt-8 text-3xl">— with love, Mira ✿</p>
      </Reveal>
      {[
        "left-[8%] top-1/3 text-tea h-12 w-12",
        "right-[12%] top-1/4 text-fern h-8 w-8",
        "left-[20%] bottom-16 text-gold h-8 w-8",
        "right-[8%] bottom-20 text-mahogany h-10 w-10",
      ].map((c, i) => (
        <motion.div
          key={i}
          className={`absolute ${c}`}
          initial={{ scale: 0, rotate: -90 }}
          whileInView={{ scale: 1, rotate: 0 }}
          viewport={{ once: true }}
          transition={{ type: "spring", delay: 0.4 + i * 0.15 }}
        >
          <Star className="floaty h-full w-full" />
        </motion.div>
      ))}
      <p className="mt-24 text-xs tracking-widest text-muted-foreground uppercase">© 2026 Mira Lind · handmade on the internet</p>
    </section>
  );
}

function Index() {
  return (
    <main id="top">
      <Nav />
      <Cover />
      <About />
      <Experience />
      <Hobbies />
      <Skills />
      <Contact />
      <Ending />
    </main>
  );
}
